## Script using az cli and Bicep to Deploy Resources to Azure

param ([string][Parameter( Mandatory=$false)]$PathToCsv="./ListOfRessourceGroup.csv",
       [string][Parameter( Mandatory=$false)]$Delimiter=";")


if (Test-Path $PathToCsv)
{
    # $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  | Where-Object { $_.IsDataDesk -eq "0" }
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }

 #not used
 #$TenantId=az account show --query tenantId
 Foreach ($Group in $Groups)
        {
            $location=$Group.location
            $ResourceGroupName =$Group.ResourceGroup            
            $Suffix=$Group.suffix
            $location=$Group.location
            # az group create -g $ResourceGroupName -l $location  --tags deployprefix=$Suffix          
            
            $AADGroup=$Group.AADGroup
            write-host "Deploying resources to '$ResourceGroupName'"
            az deployment group create --name "main.resources.bicep" `
                            --resource-group $ResourceGroupName `
                            --template-file "02-main.resources.bicep" `
                            --parameters location=$location suffix=$Suffix team=$AADGroup tenantId=$TenantId
            
            write-host "Addding lock Read Only"
            
        }