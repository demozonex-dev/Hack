
$PathToCsv="$01-ProvidersToRegistered.csv
# if (Test-Path )
# {
#     # $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  | Where-Object { $_.IsDataDesk -eq "0" }
#     $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  
# }
# else 
#  {
#     write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
#     return;
#  }

# #az provider list --query "[?registrationState=='Registered'].{name:namespace,status:registrationState}" --output table 

# az provider register -n "Microsoft.compute"