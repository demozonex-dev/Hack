## 
param ([string][Parameter( Mandatory=$false)]$PathToCsv=".\ListOfRessourceGroup.csv",
       [string][Parameter( Mandatory=$false)]$Delimiter=";",
       [string][Parameter( Mandatory=$false)]$PathToRoles=".\ListOfRoles.csv")


if (Test-Path $PathToCsv)
{
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter 
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }
 
 if (Test-Path $PathToRoles)
 {
     $Roles = Import-CSV -Path $PathToRoles -Delimiter $Delimiter 
 }
 else 
  {
     write-host "File $PathToRoles does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
     return;
  }

  
  
  $DataDesk=$Groups | Where-Object { $_.IsDataDesk -eq "1" }
 

$dataDeskGroupAAD=$DataDesk.AADGroup  
$AadDatadeskGroupId=az ad group show -g $dataDeskGroupAAD --query "id" --output tsv            
$ResourceGroupName="rg-Lef-SharedData"
az role assignment  create --resource-group $ResourceGroupName --assignee $AadDatadeskGroupId --role "Storage Blob Data Contributor" --query roleDefinitionId
az role assignment  create --resource-group $ResourceGroupName --assignee $AadDatadeskGroupId --role "Contributor" --query roleDefinitionId

 Foreach ($Group in $Groups)
        {
            $ResourceGroupName =$Group.ResourceGroup
            
                                 
            write-host "Applying RBAC to the resource group  '$ResourceGroupName'"            
            foreach($role in $Roles)
                {
                                
                    $RoleName=$role.role
                    write-host "Assigning $RoleName"                    
                    #assign datadesk group to each group
                    az role assignment  create --resource-group $ResourceGroupName --assignee $AadDatadeskGroupId --role $RoleName --query roleDefinitionId                                        
                }
               
        }