## 
param ([string][Parameter( Mandatory=$false)]$PathToCsv=".\ListOfRessourceGroup.csv",
       [string][Parameter( Mandatory=$false)]$Delimiter=";")


if (Test-Path $PathToCsv)
{
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter 
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }
 
 

 Foreach ($Group in $Groups)
        {

            
            
            $AadGroupId=az ad group show -g $Group.AADGroup --query "id" --output tsv            
            #get the subscription id from the authenticated account
            $Subscriptionid=az account show --query id

            # assign this role at the subscription level (Mandatory)
            az role assignment  create --assignee $AadGroupId --role "Cognitive Services Usages Reader" --subscription $Subscriptionid --query roleDefinitionId 
                                   
        }