
.\01-LoginToEntraWithAz.ps1
.\02-DeployResourcesForAttendees.ps1 
.\03-CreateSharedData.ps1
.\03-DeployWebAppToAzure.ps1
.\04-ApplyRbacAttendeesToResourceGroups.ps1
.\04-ApplyRbacDataDeskToAllGroups.ps1
.\04-ApplyRbacToSubscriptionLevel.ps1

#.\05-AddingLock.ps1

