param ([string][Parameter( Mandatory=$false)]$PathToCsv=".\ListOfRessourceGroup.csv",
       [string][Parameter( Mandatory=$true)]$IpAdressRangeToAllow,
       [string][Parameter( Mandatory=$false)]$Delimiter=";")

if (Test-Path $PathToCsv)
{
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }
 foreach($group in $groups)
 {

       $ResourceGroupName =$Group.ResourceGroup
       $names=az resource list -g $ResourceGroupName  --query "[?type=='Microsoft.Web/sites'].{name:name}" | ConvertFrom-Json
       foreach($name in $names)
       {
            $WebAppName=$name.name            
       
            az webapp config access-restriction add `
                -p "100" `
                --action "Allow" `
                --description "RestrictionHack" `
                --ip-address $IpAdressRangeToAllow `
                --rule-name "IpRestrictionHack" `
                --name $WebAppName `
                -g $ResourceGroupName


            az resource update --resource-group $ResourceGroupName --name $WebAppName --resource-type "Microsoft.Web/sites" `
                --set properties.siteConfig.ipSecurityRestrictionsDefaultAction=Deny

            #SCM SITE
            az webapp config access-restriction set -g $ResourceGroupName `
                                                    -n $WebAppName `
                                                    --use-same-restrictions-for-scm-site true

            az resource update --resource-group $ResourceGroupName --name $WebAppName --resource-type "Microsoft.Web/sites" `
                                --set properties.siteConfig.scmIpSecurityRestrictionsDefaultAction=Deny

            
    }
}