# Create ressource group list

param ([string][Parameter( Mandatory=$false)]$PathToCsv=".\AADGroup.csv",
       [string][Parameter( Mandatory=$false)]$Delimiter=";")



if (Test-Path $PathToCsv)
{
    $AADGroups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter
}
else 
 {
    write-host "File $PathToCsv does not exist !!"
    return;
 }


# Create a destination csv file 

$DestinationFile = "../Step-2/ListOfRessourceGroup.csv"


if (Test-Path $DestinationFile)
{
    Remove-Item $DestinationFile
    
}



New-Item $DestinationFile 
Add-Content $DestinationFile  "ResourceGroup;AADGroup;suffix;location;isdatadesk"


$prefix="rg-hack-"
$int=0
Foreach ($AADGroup in $AADGroups) {
    
        # Check if the AAD Group Exist in the directory
        $SecurityGroup=$AADGroup.SecurityGroup
        write-host $SecurityGroup
        # $id=az ad group show -g  $SecurityGroup --query id
        # if ($null -eq $id )
        # {
        #     # Do nothing
        #     continue
        # }
        # else 
        # {            
            $random=Get-Random -Maximum 1000
            if ($int % 2 -eq 0 )
            {  
                $location="switzerlandnorth"            
            }
            else 
            {
                $location="switzerlandnorth"            
            }
            $int=$int+1        
            # Create the resource Group Name
            $SecurityGroup=$SecurityGroup.ToLower()
            $Suffix="h" + $SecurityGroup.Substring(0,3)+$random;
            $ResourceGroupName=$prefix + $SecurityGroup
            $ResourceGroupName=$ResourceGroupName.ToLower()
            $IsDataDesk=$AADGroup.IsDataDesk
            Add-Content $DestinationFile  "$ResourceGroupName;$SecurityGroup;$suffix;$location;$IsDataDesk" 

            write-host "Creating '$ResourceGroupName'"
            
            
            #az group create -g $ResourceGroupName -l $location  --tags deployprefix=$Suffix
            $ResourceGroupTags = @{
                "deployprefix" = $Suffix; 
                "team" = $SecurityGroup;                
                }
            New-AzResourceGroup -Name $ResourceGroupName -Location $location -Tag $ResourceGroupTags            
        # }
       
}

#import-csv $DestinationFile -Delimiter $Delimiter | ConvertTo-Json | Add-Content -Path $DestinationJsonFile

Write-host "File '$DestinationFile' created !!"