#to run locally : 
#  - install git command line
#  - run the following command as admin user on windows to install Azure powershelle module : 
#               Install-Module -Name Az -Repository PSGallery -Force -AllowClobber
#               Connect-AzAccount -Tenant [GUID] -Subscription [GUID]
#  
# or run this script from a azure shell (but take care of deconnection timeout)


$repoName="azure-open-ai-embeddings-qna"                              
$repoToClone = "https://github.com/flyingoverclouds/" + $repoName
$rgScanPrefix = "rg-hkt-"
$deployPrefixTagName = "deployprefix"

Write-Host "--->>> Cloning project from " $repoToClone " ...."
git clone $repoToClone

Write-Host "--->>> retrieving target resourceGroup ...."
$targetRgs = Get-AzResourceGroup | Where-Object { $_.ResourceGroupName.toLower().StartsWith($rgScanPrefix) }
Write-Host $targetRgs.Count " deployment to execute in :"
foreach($rg in $targetRgs)
{
        Write-Host "  -" $rg.ResourceGroupName "in" $rg.Location
}

$paramTemplate = Get-Content ./02-deploy-PARAMTEMPLATE.json -Raw   

foreach($rg in $targetRgs)
{
        $resinrg = Get-AzResource -ResourceGroupName $rg.ResourceGroupName
        # $deployPrefix = $rg.ResourceGroupName.toLower().Replace($rgScanPrefix,"") # extrcation du deploydeplix a partir du rgname moins le prefix de selection
        $deployPrefix = $rg.Tags[$deployPrefixTagName] #extraction du deployprefix a partir d'un tag

        if ($resinrg.Count -gt 1)
        {
                $errrgname=$rg.ResourceGroupName
                Write-Warning "--->>> ERROR : Resource group  [$errrgname] aleardy contains resources. NO DEPLOYMENT"
        }
        elseif ([string]::IsNullOrEmpty($deployPrefix))
        {
                $errrgname=$rg.ResourceGroupName
                Write-Warning "--->>> ERROR : Deploy prefix tag [$deployPrefixTagName] not found in resourcegroup [$errrgname]. NO DEPLOYMENT"
        }
        else {

                if (![string]::IsNullOrEmpty($deployPrefix))
                {

                        Write-Host "--->>> Deploying in " $rg.ResourceGroupName "[" $rg.Location "] with unique prefix [" $deployPrefix "]"

                        # generation dedicated param file for deployement 
                        $dedicatedParamTemplate =  $paramTemplate.Replace("XXXREPLACEDBYPREFIX",$deployPrefix)
                        $dedicatedParamTemplateFilename = "99-deploy-param-" + $deployPrefix + ".json"
                        $dedicatedParamTemplate  | Out-File -filepath $dedicatedParamTemplateFilename
                

                        # #  start deployment with dedicated param file
                        New-AzResourceGroupDeployment `
                                -ResourceGroupName $rg.ResourceGroupName `
                                -TemplateFile './azure-open-ai-embeddings-qna/infrastructure/deployment_ACS.json' `
                                -TemplateParameterFile $dedicatedParamTemplateFilename

                        Write-Host "--->>> deleting temporary parameter file $dedicatedParamTemplateFilename"
                        Remove-Item $dedicatedParamTemplateFilename -Force
                }
        }
}


Write-Host "--->>> Cleaning local clone ...."
Remove-Item $repoName -Recurse -Force


Write-Host "--->>> Hackaton deployment done. Please check and verify console output and azure portal "

