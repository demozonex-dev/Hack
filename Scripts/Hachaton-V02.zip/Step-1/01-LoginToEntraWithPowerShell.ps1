# 
param ([string][Parameter( Mandatory=$true)]$subcriptionId,
       [string][Parameter( Mandatory=$true)]$MicrosoftEntraTenantId)



       Connect-AzAccount -Subscription $SubcriptionId -Tenant $MicrosoftEntraTenantId
