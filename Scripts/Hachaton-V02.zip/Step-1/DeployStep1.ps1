
$ready=Read-Host "Are you ready to deploy to Azure subscription? (Y/N)"
if ($ready -eq "N")
{
    return 
}

.\01-LoginToEntraWithPowerShell.ps1
.\02-CreateRessourceGroupFromEntraGroup.ps1
.\03-deploy-rgs.ps1