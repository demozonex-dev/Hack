# 
param ([string][Parameter( Mandatory=$true)]$subcriptionId,
       [string][Parameter( Mandatory=$true)]$MicrosoftEntraTenantId)



az login --tenant $MicrosoftEntraTenantId
# Set the default subscription for the next commands in case of multi-subscription
az account set --subscription $subcriptionId

# show the account logged
az account show 

# clear the local account cache
# az account clear

