

$Suffix="sharedlef" + $random;


# Create a resource Group in order to share data

$ResourceGroupName="rg-SharedData"
$Location="switzerlandnorth"
Write-Host "Creating resource for sharing the data in $ResoureGroupName"
az group create -g $ResourceGroupName -l $location  
write-host "Deploying resources to '$ResourceGroupName'"
            az deployment group create --name "main.SharedData.bicep" `
                            --resource-group $ResourceGroupName `
                            --template-file "02-main.shareddata.bicep" `
                            --parameters location=$location suffix=$Suffix team="All"