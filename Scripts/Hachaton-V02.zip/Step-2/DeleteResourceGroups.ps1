param ([string][Parameter( Mandatory=$false)]$PathToCsv="./ListOfRessourceGroup.csv",
       [string][Parameter( Mandatory=$false)]$Delimiter=";",
       [string][Parameter( Mandatory=$false)]$location="westeurope")




if (Test-Path $PathToCsv)
{
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter 
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }
 
$ready=Read-Host "Are you sure you want to delete the Azure Resource? (Y/N)"
if ($ready -eq "N")
{
    return 
}
az lock delete --name "hacklock" --resource-group "rg-lef-SharedData"        
az group delete -g "rg-lef-SharedData"  --no-wait  --yes
 Foreach ($Group in $Groups)
        {
            $ResourceGroupName =$Group.ResourceGroup
            write-host "Deleting '$ResourceGroupName'"      
            az lock delete --name "hacklock" --resource-group $ResourceGroupName       
            az group delete -g $ResourceGroupName  --no-wait  --yes
        }