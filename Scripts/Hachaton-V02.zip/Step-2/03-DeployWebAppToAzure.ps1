param ([string][Parameter( Mandatory=$false)]$PathToCsv="./ListOfRessourceGroup.csv",
       [string][Parameter( Mandatory=$false)]$Delimiter=";")




if (Test-Path $PathToCsv)
{
    # $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  | Where-Object { $_.IsDataDesk -eq "0" }
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }
 
 Foreach ($Group in $Groups)
        {
            $Suffix=$Group.suffix
            $ResourceGroupName =$Group.ResourceGroup
            $acrName="acr"+$suffix
            $passwordregistry=az acr credential show --resource-group $ResourceGroupName --name $acrName --query passwords[0].value --output tsv
            $AADGroup=$Group.AADGroup
            $location=$Group.location
            write-host "Deploying Web App to '$ResourceGroupName'"
            az deployment group create --name "main.webapp.bicep" `
                            --resource-group $ResourceGroupName `
                            --template-file "03-main.webapp.bicep" `
                            --parameters location=$location suffix=$Suffix team=$AADGroup secret=$passwordregistry

            
            $WebAppName="webapp"+$Suffix
            $WebHookName=$WebAppName+"Hook"
            $WebhookUrl=az webapp deployment container show-cd-url -g $ResourceGroupName -n $WebAppName --query CI_CD_URL
            Write-Host "Creating webhook for CI/CD"
            #+Start-Sleep '15'
            az acr webhook create -n $WebHookName -r $acrName  -g $ResourceGroupName --uri $WebhookUrl --actions "push"  #--scope "welcometohackaton"
        }