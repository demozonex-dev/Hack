## 
param ([string][Parameter( Mandatory=$false)]$PathToCsv=".\ListOfRessourceGroup.csv",
       [string][Parameter( Mandatory=$false)]$Delimiter=";",
       [string][Parameter( Mandatory=$false)]$PathToRoles=".\ListOfRoles.csv")


if (Test-Path $PathToCsv)
{
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter | Where-Object { $_.IsDataDesk -eq "0" }
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }
 
 if (Test-Path $PathToRoles)
 {
     $Roles = Import-CSV -Path $PathToRoles -Delimiter $Delimiter 
 }
 else 
  {
     write-host "File $PathToRoles does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
     return;
  }

 
 Foreach ($Group in $Groups)
        {

            $ResourceGroupName =$Group.ResourceGroup  

            
            write-host "Applying RBAC to  the resource group  '$ResourceGroupName'"
            $AadGroupId=az ad group show -g $Group.AADGroup --query "id" --output tsv                                    
            $ResourceGroupName="rg-SharedData"
            az role assignment  create --resource-group $ResourceGroupName --assignee $AadGroupId --role "Storage Blob Data Contributor" --query roleDefinitionId
            az role assignment  create --resource-group $ResourceGroupName --assignee $AadGroupId --role "Contributor" --query roleDefinitionId
            
        }