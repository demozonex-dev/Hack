
.\01-LoginToEntraWithAz.ps1
.\02-DeployResourcesForAttendees.ps1 
.\02-CreateSharedData.ps1
.\03-DeployWebAppToAzure.ps1
.\04-ApplyAllRbacScripts
#.\05-AddingLock.ps1

