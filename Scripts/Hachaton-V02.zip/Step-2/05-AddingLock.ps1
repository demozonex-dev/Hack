param ([string][Parameter( Mandatory=$false)]$PathToCsv=".\ListOfRessourceGroup.csv",       
       [string][Parameter( Mandatory=$false)]$Delimiter=";")

if (Test-Path $PathToCsv)
{
    $Groups = Import-CSV -Path $PathToCsv -Delimiter $Delimiter  
}
else 
 {
    write-host "File $PathToCsv does not exist, run 1-CreateRessourceGroupFromEntraGroup.ps1 before"
    return;
 }
 $ResourceGroupName="rg-hkt-SharedData"
 az group lock create --lock-type CanNotDelete -n "hacklock" -g $ResourceGroupName --query "[resourceGroup,type]" --output table

 foreach($group in $groups)
 {

       $ResourceGroupName =$Group.ResourceGroup
       write-host "Adding lock to $ResourceGroupName resource group"
       az group lock create --lock-type CanNotDelete -n "hacklock" -g $ResourceGroupName --query "[resourceGroup,type]" --output table
}


