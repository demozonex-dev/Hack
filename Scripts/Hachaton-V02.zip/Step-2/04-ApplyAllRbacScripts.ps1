.\04-ApplyRbacAttendeesToResourceGroups.ps1
.\04-ApplyRbacDataDeskToAllGroups.ps1
.\04-ApplyRbacToSubscriptionLevel.ps1
.\04-ApplyRbacToSharedData.ps1